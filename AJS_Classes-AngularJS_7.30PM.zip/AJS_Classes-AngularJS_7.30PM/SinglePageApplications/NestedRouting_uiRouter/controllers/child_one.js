app.controller("child_one",child_one);
function child_one($scope) {
    $scope.var_three="I am from child one controller !";
}