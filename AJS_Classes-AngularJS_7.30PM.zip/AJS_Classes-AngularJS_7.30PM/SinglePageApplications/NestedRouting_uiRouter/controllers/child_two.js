app.controller("child_two",child_two);
function child_two($scope) {
    $scope.var_four="I am from child two controller !";
}