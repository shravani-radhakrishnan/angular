app.controller("ctrl_two",ctrl_two);
function ctrl_two($scope) {
    $scope.var_two = "I am from controller two !";
}